package logic

import (
	"flag"
	"fmt"
	"github.com/dappley/go-dappley/config"
	"github.com/dappley/go-dappley/core/account"
	"github.com/dappley/go-dappley/core/utxo"
	dependable_configpb "github.com/dappley/go-dappley/tool/dependable_testing/pb"
	account_ron "github.com/dappley/go-dappley/tool/dependable_testing/sdk"
	"github.com/dappley/go-dappley/tool/dependable_testing/service"
	logger "github.com/sirupsen/logrus"
	"math"
	"runtime"
	"sync"
	"time"
)

const (
	configFilePath = "../dependable_testing/default.conf"
	logFreshTime   = 5  //刷新日志间隔
)
//说明：default.conf: goCount设置为10，tps为2
func TestSmartContract() {
	var err error
	configs := &dependable_configpb.Config{}
	config.LoadConfig(configFilePath, configs)
	var filePath string
	flag.StringVar(&filePath, "f", configFilePath, "Configuration File Path. Default to conf/default.conf")
	//config
	runTime24 := 86400 //运行交易时间  1小时=3,600，24小时=86,400

	//网络服务
	serviceClient := service.NewServiceClient(configs.GetIp(), configs.GetPort())
	minerAccount := account.NewAccountByPrivateKey(configs.GetMinerPrivKey())
	//存放创建的aacount

	logger.Info("智能合约测试场景...")
	logger.Info("测试目的：")
	logger.Info("验证系统智能合约场景下的表现")
	logger.Info("测试步骤：")
	logger.Info("在", runTime24, "秒内,向服务器持续发送交易请求,TPS为",configs.GoCount*configs.Tps,",然后验证交易成功率")
	logger.Info("正在初始化...")

	acInfo := account_ron.NewAccountInfo()
	stopChan := make(chan bool,6000)
	startTest := false

	//var goGoroutineMap sync.Map
	//for i := int32(0); i < configs.GetGoCount(); i++ {
	//	go StartTransactionGoroutine(
	//		i,
	//		&goGoroutineMap,
	//		serviceClient,
	//		acInfo,
	//		minerAccount.GetAddress().String(),
	//		configs,
	//		&startTest,
	//		stopChan)
	//}
    RESTART:
    var goGoroutineMap sync.Map
	accounts, err := account_ron.ReadAccountFromFile()
	if err != nil {
		logger.Info("未找到account.dat，根据default启动测试，")
		logger.Info("正在向矿工获取token...")
		//交易生成
		for i := int32(0); i < configs.GetGoCount(); i++ {
			go StartTransactionGoroutine(
				i,
				&goGoroutineMap,
				serviceClient,
				acInfo,
				minerAccount.GetAddress().String(),
				configs,
				&startTest,
				stopChan)
		}
		time.Sleep(100*time.Millisecond)
		//acInfo.WaitTillGetToken(configs.GetAmountFromMinner() * uint64(configs.GetGoCount()))
		var sum uint64
		for {
			if startTest == true{
				startTest = false
				logger.Info("....开始重启...")
				goto RESTART
			}
			goGoroutineMap.Range(func(k, v interface{}) bool {
				sum ++
				return true
			})
			if sum == uint64(configs.GetGoCount()) {
				logger.Info("测试工具初始化完成")  //部署合约完成
				break
			}
			sum = 0
			time.Sleep(100 * time.Millisecond)
		}
		account_ron.SaveAccountToFile(acInfo) //写入account.bat
	} else {
		acInfo.Accounts = accounts
		lenAccount := len(acInfo.Accounts)
		if lenAccount%2 != 0 {
			logger.Error("account.dat出错，请删除重启程序")
			return
		}
		logger.Info("找到",len(acInfo.Accounts)/2," 对账户。 TPS为", int32(len(acInfo.Accounts)/2)*configs.Tps)
		for i := 0; i < lenAccount; i = i + 2 {
			fromAccount := acInfo.Accounts[i]
			acInfo.FromAccounts = append(acInfo.FromAccounts,fromAccount)
			toAccount := acInfo.Accounts[i+1]
			acInfo.ToAccounts = append(acInfo.ToAccounts,toAccount)
			acInfo.FromAddress = append(acInfo.FromAddress, fromAccount.GetAddress().String())
			acInfo.Balances[fromAccount.GetAddress().String()] = uint64(serviceClient.GetBalance(fromAccount.GetAddress().String()))
			acInfo.ToAddress = append(acInfo.ToAddress, toAccount.GetAddress().String())
			acInfo.Balances[toAccount.GetAddress().String()] = uint64(serviceClient.GetBalance(toAccount.GetAddress().String()))

			go StartTransactionFromFile(
				serviceClient,
				acInfo,
				minerAccount.GetAddress().String(),
				configs,
				&startTest,
				stopChan,
				fromAccount,
				toAccount)
		}
	}

	//acInfo.WaitTillGetToken(serviceClient,configs.GetAmountFromMinner()*uint64(configs.GetGoCount()))

	startTest = true
	logger.Info("开始发送交易...")
	logger.Info("当前时间为：",time.Now().Format("2006-01-02 15:04:05"))

	//日志刷新
	//stopLog := make(chan bool)
	//go LogPrinter(acInfo, serviceClient, stopLog)

	//让交易发送一段时间
	//time.Sleep(time.Duration(runTime24) * time.Second)

	for {
		time.Sleep(1*time.Second)
		logger.Info("测试正在进行中.....")
		if !startTest{
			logger.Info("发现错误...")
			//停止日志和所有go程交易
			//stopLog <- true
			for i := int32(0); i < configs.GetGoCount(); i++ {
				stopChan <- true
			}
			logger.Info("关闭所有进程，15秒后重启...")
			time.Sleep(15 * time.Second)
			logger.Info("开始重启...")
			goto RESTART
		}
	}
	logger.Info("交易发送停止,已用时间测试：", runTime24, "秒.")

	logger.Info("验证开始...")
	//计算发交易双方的balance
	toSum, localToSum := CheckTransactionNumber(acInfo, serviceClient)
	logger.Info("发送交易：", localToSum, "笔，成功接收交易:", toSum, "笔.")
	logger.Info("交易成功率：", fmt.Sprintf("%.2f", float64(toSum)/float64(localToSum)*100), "%")
	logger.Info("平均TPS：", math.Round(float64(toSum)/float64(runTime24)))
	logger.Info("测试结束")
}


//开始交易，from问矿工要钱，再给to,没钱了再问矿工要，一直重复
func StartTransactionGoroutine(i int32,goGoroutineMap *sync.Map,service *service.Service, accInfo *account_ron.AccountInfo, minnerAcc string, config *dependable_configpb.Config, start *bool, stop chan bool) {
	fromAccount := accInfo.CreateFromAccount()
	fromAcc := fromAccount.GetAddress().String()

	var utxoTx *utxo.UTXOTx
	var err error
	if accInfo.GetBalance(fromAcc) < config.AmountPerTx {
		err,utxoTx = service.GetToken(accInfo, minnerAcc, fromAcc, config.AmountFromMinner+1)
		if err != nil{
			logger.Error("service GetToken error:",err)
			*start = true
			return
		}
	}
	if utxoTx == nil{  // 并发太多会出现转账失败
		goGoroutineMap.Store(i,1)
		logger.Error("utxo is nil.")
		*start = false
		return
	}
	time.Sleep(1*time.Second)
	contract := `'use strict';
			var VisitorSign=function(){
			};

			VisitorSign.prototype={
				put_visitor_sign:function(key,value){
					LocalStorage.set(key,value)
				},

				get_visitor_sign:function(key){
					return LocalStorage.get(key)
				},
				dapp_schedule:function(){
				}
			};
			module.exports=new VisitorSign();
		`
	var contractAddr string
	if accInfo.GetBalance(fromAcc) > config.AmountPerTx  {
		err,contractAddr = service.DeploySmartContract(fromAccount.GetPubKeyHash(), utxoTx, accInfo, 1, fromAcc, "",1,30000,1,contract)
		if err != nil{
			logger.Error("service DeploySmartContract error:",err)
			*start = true
			return
		}
	}

	logger.Info("Contract Address:",contractAddr)
	accInfo.CreateToAccount(contractAddr)

	utxoTx = service.GetUtxo(accInfo, minnerAcc, fromAcc, config.AmountFromMinner)
	goGoroutineMap.Store(i,1)
	ticker := time.NewTicker(time.Microsecond * time.Duration(1000000/config.Tps)) //定时1秒
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			//本地没钱了就问服务器要，如果使用服务器的余额判断，因为延迟关系，本地早没钱了，
			//还在发送交易，传到服务器，服务器会接受到很多不存在的交易。
			if accInfo.GetBalance(fromAcc) <= config.AmountPerTx { //每次交易就发1个token
				err,utxoTx = service.GetToken(accInfo, minnerAcc, fromAcc, config.AmountFromMinner)
				if err != nil{
					logger.Error("service GetToken error:",err)
					*start = false
				}
			}
			if utxoTx == nil{  // 并发太多会出现转账失败
				logger.Error("utxo is nil.")
				*start = false
			}
			InvokingContract := `{"function":"put_visitor_sign","args":["file-name","SHA-1-sign"]}`
			if accInfo.GetBalance(fromAcc) > config.AmountPerTx && *start {
				err = service.InvokingSmartContract(fromAccount.GetPubKeyHash(), utxoTx, accInfo, 1, fromAcc, contractAddr,1,30000,1,InvokingContract)
				if err != nil{
					logger.Error("service InvokingSmartContract error:",err)
					*start = false
				}
			}
		case <-stop:
			logger.Info("线程退出.......")
			runtime.Goexit() //退出go线程
		}
	}
}

//开始交易，from问矿工要钱，再给to,没钱了再问矿工要，一直重复
func StartTransactionFromFile(ser *service.Service, accInfo *account_ron.AccountInfo, minnerAcc string, config *dependable_configpb.Config, start *bool, stop chan bool, fromAccount, toAccount *account.Account) {
	var utxoTx *utxo.UTXOTx
	var err error
	fromAcc := fromAccount.GetAddress().String()
	utxoTx,_,err  = ser.GetUTXOTxFromServer(fromAcc)
	if err != nil {
		logger.Error("Get UTXOTx error:", err)
	}
	ticker := time.NewTicker(time.Microsecond * time.Duration(1000000/config.Tps)) //定时1秒
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			//本地没钱了就问服务器要，如果使用服务器的余额判断，因为延迟关系，本地早没钱了，
			//还在发送交易，传到服务器，服务器会接受到很多不存在的交易
			if accInfo.GetBalance(fromAcc) <= 1 { //每次交易就发1个token
				err,utxoTx = ser.GetToken(accInfo, minnerAcc, fromAcc, config.AmountFromMinner)
				if err!=nil{
					logger.Error("GetBalance failed,error:",err)
					*start=false
				}
			}
			if utxoTx == nil{  // 并发太多会出现转账失败
				logger.Error("utxo is nil.")
				*start = false
			}
			if accInfo.GetBalance(fromAcc) > 1 && *start {
				InvokingContract := `{"function":"put_visitor_sign","args":["file-name","SHA-1-sign"]}`
				err = ser.InvokingSmartContract(fromAccount.GetPubKeyHash(), utxoTx, accInfo, 1, fromAcc, toAccount.GetAddress().String(),1,30000,1,InvokingContract)
				if err!=nil{
					logger.Error("GetBalance failed,error:",err)
					*start=false
				}
			}
		case <-stop:
			logger.Info("交易Go程退出...")
			runtime.Goexit() //退出go线程
		}
	}
}

func CheckTransactionNumber(acInfo *account_ron.AccountInfo, serviceClient *service.Service) (int64, int64) {
	timeOut:= 25 //交易结束发送后，等待交易打包最长时间,单位秒
	var toSum, localToSum int64
	for _, address := range acInfo.ToAddress {
		if address == "" {
			continue
		}
		localToSum = localToSum + int64(acInfo.GetBalance(address))
	} //这里只验证交易数量，丢失数量，交易准确性不是这在这个测试中

	count := 0
	for {
		toSum = 0 //重新计算服务器接收到的交易量
		for _, address := range acInfo.ToAddress {
			if address == "" {
				continue
			}
			toSum = toSum + int64(serviceClient.GetBalance(address))
		}
		if toSum != localToSum {
			logger.Info("等待服务器打包交易...")
			count++
			time.Sleep(time.Second * 5)
		} else {
			break
		}

		if count == timeOut/5 {
			logger.Info("等待超时...")
			break
		}

	}
	return toSum, localToSum
}

func LogPrinter(acInfo *account_ron.AccountInfo, serviceClient *service.Service, out chan bool) {
	ticker := time.NewTicker(time.Second * logFreshTime)
	defer ticker.Stop()
	var toSum, lastToSum int64
	for {
		select {
		case <-ticker.C:
			for _, address := range acInfo.ToAddress {
				if address == "" {
					continue
				}
				toSum = toSum + int64(serviceClient.GetBalance(address))
			}
			if toSum>=lastToSum{
				logger.Info("交易发送中，当前TPS：", (toSum-lastToSum)/int64(logFreshTime))
			}else{
				//logger.Info("toSum: ", toSum,",lastToSum: ",lastToSum)
			}
			lastToSum = toSum
			toSum = 0
		case <-out:
			runtime.Goexit()
		}
	}
}