package main

import (
	"github.com/dappley/go-dappley/tool/dependable_testing/logic"
)

func main() {
	logic.TestSmartContract()
	//logic.TestTransaction()
	return
}