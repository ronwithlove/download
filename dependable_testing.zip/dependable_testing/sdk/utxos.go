package account_ron

import (
	"github.com/dappley/go-dappley/core/utxo"
)

type UTXOS struct {//uxto pool
	*utxo.UTXOTx
}